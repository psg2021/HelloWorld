package konkuk.sunggeun.helloworld;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ChatModel implements Serializable {
        private static final long serialVersionUID = 1L;
//    public Map<String, Boolean> users = new HashMap<>();
//    public Map<String, Comment> comments = new HashMap<>();

//    public static class Comment implements Serializable{
        String uid;
        String message;
//    }
    //static안해주니 다른데서 이걸 선언을 못해준다.
}
