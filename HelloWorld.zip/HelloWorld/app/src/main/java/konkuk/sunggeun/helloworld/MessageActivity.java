package konkuk.sunggeun.helloworld;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class MessageActivity extends AppCompatActivity {
    private Button button;
    private EditText editText;
    private RecyclerView recyclerView;
    private CustomAdapter mAdapter;
    private LinearLayoutManager mLinearLayoutManager;
    private Socket socket;
    //OutputStream sendBuffer;
    //InputStream recvBuffer;
    BufferedReader in;
    PrintWriter out;
    String recvMsg;
    //String sendMsg;
//    List<ChatModel.Comment> list;
    List<ChatModel> list;

    ObjectOutputStream oos;
    ObjectInputStream ois;


    private static String ip = "192.168.43.168";
    private static  int port = 5568;

    private String uid;
    private String destinationUid;

    protected void onStop() {
        super.onStop();
        try{
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.message_activity);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
//
        uid = "me"; // 나의 아이디.
        destinationUid = "you"; // 상대방의 아이디. 지금은 에코채팅이라 일단 you로 고정해두었음.
//
        button = (Button)findViewById(R.id.messageActivity_button);
        editText = (EditText)findViewById(R.id.messageActivity_editText);

        recyclerView = (RecyclerView)findViewById(R.id.messageActivitiy_recyclerview);
        mLinearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLinearLayoutManager);

        list = new ArrayList<>();
        mAdapter = new CustomAdapter(list);
        recyclerView.setAdapter(mAdapter);

        //왜 여기서 에러가 나는걸까....
        //recyclerView.setAdapter(new RecyclerViewAdapter(list));
        //mAdapter = new CustomAdapter(list);
        //recyclerView.setAdapter(mAdapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //여기가 버튼 눌렸을때 해주는 행동이다.
                //ChatModel chatModel = new ChatModel();
                //chatModel.users.put(uid, true);
                //chatModel.users.put(destinationUid, true);
                //채팅방에 나랑 서버 두명있는거임.
                //위에부분은 일단은 필요없을것 같아 일단 빼둔다. 서버랑 나랑 아이디만 구별하면되지 아직 채팅방까지 구별할 필요는 없다.

//                ChatModel.Comment comment = new ChatModel.Comment();
                ChatModel comment = new ChatModel();
                comment.uid = uid;
                comment.message = editText.getText().toString();
                //이 코멘트를 서버로 날려야 되는데 어떻게 날리지..

                try {
                    oos.writeObject(comment);
                    oos.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //서버로 날렸으면 이제 해야할거는 recyclerview에 넣어주는것.
                list.add(comment);
                mAdapter.notifyDataSetChanged();
                //일단 이렇게 넣어준다고 해두자.
                /*

                sendMsg = editText.getText().toString();
                if(sendMsg != null){
                    try{
                        out.println(sendMsg);
                        //sendBuffer.write(sendMsg.getBytes());
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
                */
            }
        });

        Thread worker = new Thread(){
            public void run(){
                try{
                    socket = new Socket(ip,  port);
                    oos = new ObjectOutputStream(socket.getOutputStream());
                    ois = new ObjectInputStream(socket.getInputStream());
                    //out = new PrintWriter(socket.getOutputStream(), true);
                    //in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    //sendBuffer = socket.getOutputStream();
                    //recvBuffer = socket.getInputStream();
                }catch (IOException e){
                    e.printStackTrace();
                }
                try{
                    while(true){
                        //recvMsg = recvBuffer.toString();
                        //recvMsg = in.readLine();
//                        ChatModel.Comment comment = (ChatModel.Comment)ois.readObject();
                        ChatModel comment = (ChatModel)ois.readObject();
                        list.add(comment);
                        mAdapter.notifyDataSetChanged();

                        //msg.add(recvMsg);
                        //mAdapter.notifyDataSetChanged();
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        worker.start();

    }

    // 여기는 강의에 있던 내용
//    class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{
//        List<ChatModel.Comment> mComments;
//
//        public RecyclerViewAdapter(List<ChatModel.Comment> comments){
//            mComments = comments;
//        }
//
//        @NonNull
//        @Override
//        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
//            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_message,viewGroup, false);
//            return new MessageViewHolder(view);
//        }
//
//        @Override
//        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
//            MessageViewHolder messageViewHolder = (MessageViewHolder) viewHolder;
//
//            if(mComments .get(i).uid.equals("me")){
//                messageViewHolder.textView_message.setText(mComments.get(i).message);
//                messageViewHolder.textView_message.setBackgroundResource(R.drawable.rightbublle);
//                messageViewHolder.textView_message.setTextSize(25);
//            }else{
//                messageViewHolder.textView_message.setText(mComments.get(i).message);
//                messageViewHolder.textView_message.setBackgroundResource(R.drawable.leftbubble);
//                messageViewHolder.textView_message.setTextSize(25);
//            }
//        }
//
//        @Override
//        public int getItemCount() {
//            return mComments.size();
//        }
//
//        private class MessageViewHolder extends RecyclerView.ViewHolder{
//            public TextView textView_message;
//
//            public MessageViewHolder(View v){
//                super(v);
//                textView_message = (TextView) itemView.findViewById(R.id.messageItem_textView_message);
//            }
//        }
//
//
//   }




}
