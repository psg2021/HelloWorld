package konkuk.sunggeun.helloworld;

import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import java.io.*;
import java.net.Socket;

public class MainActivity extends Activity {
    private Socket socket;
    //OutputStream sendBuffer;
    //InputStream recvBuffer;
    BufferedReader in;
    PrintWriter out;
    String recvMsg;
    String sendMsg;
    EditText input;
    Button button;
    TextView output;
    private static String ip = "192.168.0.12";
    private static  int port = 5568;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        setContentView(R.layout.activity_layout);

        input = (EditText) findViewById(R.id.myInput);
        button = (Button) findViewById(R.id.myButton);
        output = (TextView) findViewById(R.id.myLog);

        //버튼을 눌렀을때 보내준다.
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMsg = input.getText().toString();
                if(sendMsg != null){
                    try{
                        out.println(sendMsg);
                        //sendBuffer.write(sendMsg.getBytes());
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        });

        Thread worker = new Thread(){
            public void run(){
                try{
                    socket = new Socket(ip,  port);
                    out = new PrintWriter(socket.getOutputStream(), true);
                    in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    //sendBuffer = socket.getOutputStream();
                    //recvBuffer = socket.getInputStream();
                }catch (IOException e){
                    e.printStackTrace();
                }
                try{
                    while(true){
                        //recvMsg = recvBuffer.toString();
                        recvMsg = in.readLine();
                        output.post(new Runnable(){
                            public void run(){
                                output.setText(recvMsg);
                            }
                        });
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        worker.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        try{
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initUI(){
        setContentView(R.layout.activity_layout);

        input = (EditText) findViewById(R.id.myInput);
        button = (Button) findViewById(R.id.myButton);
        output = (TextView) findViewById(R.id.myLog);

        //버튼을 눌렀을때 보내준다.
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMsg = input.getText().toString();
                if(sendMsg != null){
                    try{
                       // sendBuffer.write(sendMsg.getBytes());
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    //쓰레드는 받는거 계속 돌려준다.
    final Thread worker = new Thread(){
        public void run(){
            try{
                socket = new Socket(ip,  port);
             //   sendBuffer = socket.getOutputStream();
               // recvBuffer = socket.getInputStream();
            }catch (IOException e){
                e.printStackTrace();
            }
            try{
                while(true){
                 //   recvMsg = recvBuffer.toString();
                    output.post(new Runnable(){
                        public void run(){
                            output.setText(sendMsg);
                        }
                    });
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };


}
