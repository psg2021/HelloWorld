package konkuk.sunggeun.helloworld

class SplashActivity {

}