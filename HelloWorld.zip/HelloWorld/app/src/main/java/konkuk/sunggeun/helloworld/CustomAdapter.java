package konkuk.sunggeun.helloworld;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {
//    private List<ChatModel.Comment> mList;
    private List<ChatModel> mList;

    public class CustomViewHolder extends RecyclerView.ViewHolder{
        protected TextView textView_message;

        public CustomViewHolder(View view) {
            super(view);
            textView_message = (TextView) view.findViewById(R.id.messageItem_textView_message);
        }
    }

//    public CustomAdapter(List<ChatModel.Comment> list){
     public CustomAdapter(List<ChatModel> list){
        this.mList = list;

    }

    public CustomViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_message,viewGroup, false);
        CustomViewHolder viewHolder = new CustomViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder viewHolder, int i) {
        //viewHolder.textView_message.setText(mList.get(i).message);
        //여기서 이제 내채팅과 서버의 채팅을 따로 표현해주자.
        if(mList.get(i).uid.equals("me")){
            viewHolder.textView_message.setText(mList.get(i).message);
            viewHolder.textView_message.setBackgroundResource(R.drawable.rightbublle);
            viewHolder.textView_message.setTextSize(25);
        }else{
            viewHolder.textView_message.setText(mList.get(i).message);
            viewHolder.textView_message.setBackgroundResource(R.drawable.leftbubble);
            viewHolder.textView_message.setTextSize(25);
        }
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }
}